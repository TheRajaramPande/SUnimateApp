package com.example.finalproject.ui.info

import androidx.lifecycle.ViewModel

class InfoViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}