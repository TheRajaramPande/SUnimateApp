package com.example.finalproject.utils

object Constants{
    val cities = listOf("Onondaga", "Rochester", "Syracuse", "Ithaca")

    val rooms = listOf("1+0", "1+1", "2+1", "3+1", "4+1", "5+1", "6+1", "7+1", "8+1")
}