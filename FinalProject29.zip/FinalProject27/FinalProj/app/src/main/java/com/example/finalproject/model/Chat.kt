package com.example.finalproject.model

data class Chat(
    val id: String,
    var name: String,
    var profileImage: String,
    var lastMessage: String,
)